using System;
using System.IO;
using System.Text;

using Amazon.Lambda.Core;
using Amazon.Lambda.KinesisEvents;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]
namespace KinesisConsumer {
    public class Function {
        public void FunctionHandler(KinesisEvent kinesisEvent, ILambdaContext context) {
            context.Logger.LogLine($"Beginning to process {kinesisEvent.Records.Count} records...");

            // Create a client
            AmazonDynamoDBClient client = new AmazonDynamoDBClient();

            Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
            {
                { "id", new AttributeValue { N = "key" } }
            };

            // Define attribute updates
            Dictionary<string, AttributeValueUpdate> row = new Dictionary<string, AttributeValueUpdate>();
            // Update item's Setting attribute
            row["TestData"] = new AttributeValueUpdate {
                Action = "PUT",
                Value = new AttributeValue { S = "something" }
            };

            // Create UpdateItem request
            UpdateItemRequest request = new UpdateItemRequest {
                TableName = "hubportal-kinesis-test",
                Key = key,
                AttributeUpdates = row
            };

            // Issue request
            client.UpdateItem(request);

            //foreach (var record in kinesisEvent.Records) {
            //    context.Logger.LogLine($"Event ID: {record.EventId}");
            //    context.Logger.LogLine($"Event Name: {record.EventName}");

            //    string recordData = GetRecordContents(record.Kinesis);
            //    context.Logger.LogLine($"Record Data:");
            //    context.Logger.LogLine(recordData);
            //}

            context.Logger.LogLine("Stream processing complete.");
        }

        private string GetRecordContents(KinesisEvent.Record streamRecord) {
            using (var reader = new StreamReader(streamRecord.Data, Encoding.ASCII)) {
                return reader.ReadToEnd();
            }
        }
    }
}
